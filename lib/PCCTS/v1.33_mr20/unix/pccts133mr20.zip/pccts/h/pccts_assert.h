#ifndef __PCCTS_ASSERT_H__
#define __PCCTS_ASSERT_H__

#ifdef PCCTS_USE_NAMESPACE_STD
#include <Cassert>
#else
#include <assert.h>
#endif

#endif
