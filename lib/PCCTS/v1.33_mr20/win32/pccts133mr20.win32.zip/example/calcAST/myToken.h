#ifndef MYTOKEN_H
#define MYTOKEN_H

/*  This file should be accompanied by DISCLAIMER.TXT stating disclaimers */

#include "numToken.h"

typedef NumToken ANTLRToken;

#endif
