#ifndef MYPANIC_H
#define MYPANIC_H

/*  This file should be accompanied by DISCLAIMER.TXT stating disclaimers */

void myPanic(const char *);

#endif
