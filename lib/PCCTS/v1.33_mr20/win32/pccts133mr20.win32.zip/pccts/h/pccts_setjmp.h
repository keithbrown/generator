#ifndef __PCCTS_SETJMP_H__
#define __PCCTS_SETJMP_H__

#ifdef PCCTS_USE_NAMESPACE_STD
#include <Csetjmp>
#else
#include <setjmp.h>
#endif

#endif
