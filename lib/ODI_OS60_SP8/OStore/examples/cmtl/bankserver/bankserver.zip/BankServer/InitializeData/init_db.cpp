// init_db.cpp: creates a database for accounts program
// This application uses the CMTL API only to illustrate how to create a
// database, set the value of a database root, etc.
#include "../Account/account.h"


void cmtl_setup(ifstream &xml_file, os_cache_pool_manager_config **cfg, 
				os_cache_pool_manager **cpm) {
 // configure cache pool manager
  *cfg = os_cache_pool_manager_config::create_from_xml(xml_file);
  // create cache pool manager with configuration information
  *cpm = os_cache_pool_manager::create(**cfg);  
}   


int main(int argc, char** argv)
{
  OS_ESTABLISH_FAULT_HANDLER {
    os_cache_pool_manager_config* cfg=NULL;
    os_cache_pool_manager* cpm=NULL;
    
    int num_checking=1000;
    int num_savings=1000;

    // name of XML file that contains information for configuring CMTL
    char* config_info = (argc > 1) ? argv[1] : "../account.xml";
    
    OS_ENTER_CMTL {
      ifstream xml_file(config_info, ios::nocreate);
      assert(xml_file);
      
      // configure CMTL's transactional caches from XML file
      cmtl_setup(xml_file, &cfg, &cpm);
      
      // create the database
      cpm->get_cache_pool(CACHE_POOL_NAME)->create_database(LOGICAL_CHECKING_DB_NAME, 0660, 1);
      
      // create an operation context for an update virtual transaction
      os_basic_transaction_context* ctx =
	os_basic_transaction_context::create();

      // Populate the checking account database.
      OS_BEGIN_VT (vt1, *ctx) {
	os_database* db =
	  os_cache::get_current()->get_database(LOGICAL_CHECKING_DB_NAME);
	// create a collection object set it as the root value
	os_set* acct_set = new(db, os_set::get_os_typespec()) os_set();
	cpm->get_root(LOGICAL_CHECKING_ROOT_NAME)->set_root_value(acct_set);
	// populate collection
	for (int i = 0; i < num_checking; i++) {
	  // create Account object
	  int account_num = i+1;
	  char account_name[25];
	  sprintf(account_name, "Acct_%08d", account_num);
	  int account_bal = rand() % 25000;
	  CAccount* a = CAccount::create(account_num, account_name, account_bal, db);
	  // insert it in collection
	  acct_set->insert(a);
	}
	os_index_path &checking_key_spec = os_index_path::create("CAccount*", "account_id", db);
	acct_set->add_index(checking_key_spec);
	db->release_pointer();
      } OS_END_VT (vt1);


	        // create the database
	cpm->get_cache_pool(CACHE_POOL_NAME)->create_database(LOGICAL_SAVINGS_DB_NAME, 0660, 1);

      // Populate the savings account database.
      OS_BEGIN_VT (vt2, *ctx) {
	os_database* db =
	  os_cache::get_current()->get_database(LOGICAL_SAVINGS_DB_NAME);
	// create a collection object set it as the root value
	os_set* acct_set = new(db, os_set::get_os_typespec()) os_set();
	cpm->get_root(LOGICAL_SAVINGS_ROOT_NAME)->set_root_value(acct_set);
	// populate collection
	for (int i = 0; i < num_savings; i++) {
	  // create Account object
	  int account_num = i+1;
	  char account_name[25];
	  sprintf(account_name, "Acct_%08d", account_num);
	  int account_bal = rand() % 25000;
	  CAccount* a = CAccount::create(account_num, account_name, account_bal, db);
	  acct_set->insert(a);
	}
	os_index_path &savings_key_spec = os_index_path::create("CAccount*", "account_id", db);
	acct_set->add_index(savings_key_spec);
	db->release_pointer();
      } OS_END_VT (vt2);

    } OS_LEAVE_CMTL;

  } OS_END_FAULT_HANDLER;  

  return 0;
}

