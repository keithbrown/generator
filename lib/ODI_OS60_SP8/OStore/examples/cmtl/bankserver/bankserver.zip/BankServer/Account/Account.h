
#include <iostream.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <ostore/cmtl.hh>
#include <ostore/coll.hh>
#include <assert.h>


// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the ACCOUNT_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// ACCOUNT_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef ACCOUNT_EXPORTS
#define ACCOUNT_API __declspec(dllexport)
#else
#define ACCOUNT_API __declspec(dllimport)
#endif

// logical names (stored in Account.cpp)
extern ACCOUNT_API const char* LOGICAL_CHECKING_DB_NAME;
extern ACCOUNT_API const char* LOGICAL_CHECKING_ROOT_NAME;
extern ACCOUNT_API const char* LOGICAL_SAVINGS_DB_NAME;
extern ACCOUNT_API const char* LOGICAL_SAVINGS_ROOT_NAME;
extern ACCOUNT_API const char* CACHE_POOL_NAME;

class ACCOUNT_API CAccount {
public:
	os_backptr bpl;

private:
	os_indexable_member(CAccount,account_id,int) account_id;
	const char* name;       // account name
	int balance;            // balance in account
    char* dupl_string(const char* s);

public:
	CAccount(const char* n, int id, int b);
    ~CAccount() { delete [] (char*)name; }
    const char* get_name() { return name; }
    int get_account_id() { return account_id; }
    int get_balance() { return balance; }
    int debit(int amount);
    int credit(int amount);
    static CAccount* create(int id, const char* n, int b,
			 os_database* db);
    static CAccount* query_checking_by_id(int id, os_database* db, os_set* coll);
    static CAccount* query_savings_by_id(int id, os_database* db, os_set* coll);
  
    // ObjectStore implements this function
    static os_typespec* get_os_typespec();
	  
private:
    // declared but unimplemented functions to prevent
    // inadvertent calls
    CAccount();
    CAccount(const CAccount&);
    CAccount& operator=(const CAccount&);  
};

