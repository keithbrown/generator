// BankConsole.h : Declaration of the CBankConsole

#ifndef __BANKCONSOLE_H_
#define __BANKCONSOLE_H_

#include "resource.h"       // main symbols
#include <mtx.h>

#include <ostore/cmtl.hh>
#include "BankUtils/BankUtils.h"

extern os_cache_pool_manager* cpm;
extern bank_initialize *bank_init;
extern bool allow_clients;
extern long clients_cnt;

/////////////////////////////////////////////////////////////////////////////
// CBankConsole
class ATL_NO_VTABLE CBankConsole : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CBankConsole, &CLSID_BankConsole>,
	public ISupportErrorInfo,
	public IBankConsole
{
public:
	CBankConsole()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_BANKCONSOLE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CBankConsole)
	COM_INTERFACE_ENTRY(IBankConsole)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IBankConsole
public:
	STDMETHOD(start)(/*[in]*/ IPipeByte *pIn);
	STDMETHOD(stop)();
};

#endif //__BANKCONSOLE_H_
