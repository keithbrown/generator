// stock_broker.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <conio.h>
#include <process.h>

#include "../BankServerInterfaces_i.c"
#include "../BankServer_i.c"
#include "../BankMsgLogInterfaces_i.c"
#include "../BankMsgLog/BankMsgLog_i.c"
 
unsigned int loop_rate = 0;  // Total number of investors using this broker
char server_hostname[40];    // Hostname of BankServer we will connect to.
IAcctMgr *acctmgr = NULL;

IStream **acctmgr_stream = NULL;
IStream **worker_acctmgr_stream = NULL;

int shutdown_worker = 0;
HANDLE worker_mutex;


/* getrandom returns a random number between min and max, which must be in
 * integer range.
 */
#define getrandom( min, max ) ((rand() % (int)(((max) + 1) - (min))) + (min))


void shutdown() {
	USES_CONVERSION;
	printf("BankClient is shutting down.\n");
	shutdown_worker = 1;  // signal worker thread to shutdown
	WaitForSingleObject(worker_mutex, INFINITE );  // wait for worker thread to shutdown
	CoInitializeEx(0, COINIT_APARTMENTTHREADED);
	IAcctMgr *local_acctmgr = NULL;
	if (acctmgr_stream) 
		CoGetInterfaceAndReleaseStream (*acctmgr_stream,  
            IID_IAcctMgr, (void**) &local_acctmgr);

	if (local_acctmgr) {
	  local_acctmgr->Release();
	}
	ReleaseMutex(worker_mutex);
	CloseHandle(worker_mutex);
	printf("GoodBye.\n");
}


BOOL WINAPI ctrl_handler_routine(DWORD dwCtrlType) {
	shutdown();
	return false;
}


// parse and check arguments
void parse_arguments(int argc, char **argv) {
    if (argc != 3) {
		printf("Error: wrong number of arguments.\n");
		exit(1);
	}
	strcpy(server_hostname, argv[1]);
	loop_rate = atoi(argv[2]);
	if (loop_rate < 0) {
		printf("Error: loop_rate must be 0 or more.\n");
		exit(1);
	}
}

void setup() {
	HRESULT hr;
	
	printf("Setting up Bank Clients.\n");
	worker_mutex = CreateMutex( NULL, FALSE, NULL );
	BOOL rval = SetConsoleCtrlHandler(ctrl_handler_routine, true);
	if (!rval) {
		printf("Error calling SetConsoleCtrlHandler.\n");
		shutdown();
	}

	CoInitializeEx(0, COINIT_APARTMENTTHREADED);
	printf("Requesting IAcctMgr interface.\n");	

	CComBSTR server_hostname_bstr(server_hostname);
    COSERVERINFO csi = { 0, server_hostname_bstr.m_str, 0, 0 };
    MULTI_QI mqi = { &IID_IUnknown, 0, 0 };
    hr = CoCreateInstanceEx(CLSID_AcctMgr, 0,
                            CLSCTX_REMOTE_SERVER,
                            &csi,1, &mqi);
	if (FAILED(hr)) {
		printf("CoCreateInstanceEx of CLSID_AcctMgr failed.\n");
		printf("Check to see if the BankServer has been registered.\n");
		shutdown();
	}
	if (FAILED(mqi.hr)) {
		printf("CoCreateInstanceEx of CLSID_AcctMgr failed.\n");
		printf("Check to see if the BankServer has been registered.\n");
		shutdown();
	}

	hr = mqi.pItf->QueryInterface(IID_IAcctMgr, (void **)&acctmgr);
	mqi.pItf->Release();
	if (FAILED(hr)) {
		printf("QueryInteface of IID_IAcctMgr failed.\n");
		shutdown();
	}	
	
	acctmgr_stream = new IStream *;
	hr = CoMarshalInterThreadInterfaceInStream
	  (IID_IAcctMgr, acctmgr, acctmgr_stream);
	if (FAILED(hr)) {
		printf("Can not marshal acctmgr interface.\n");
		shutdown();
	}
	worker_acctmgr_stream = new IStream *;
	hr = CoMarshalInterThreadInterfaceInStream
	  (IID_IAcctMgr, acctmgr, worker_acctmgr_stream);
	if (FAILED(hr)) {
		printf("Can not marshal acctmgr interface.\n");
		shutdown();
	}
	acctmgr->Release();
}

// worker thread
void simulate_clients(void *dummy)
{
	HRESULT hr;

	WaitForSingleObject(worker_mutex, INFINITE );	
	CoInitializeEx(0, COINIT_APARTMENTTHREADED);
	IAcctMgr *local_acctmgr = NULL;
	if (worker_acctmgr_stream) {
		CoGetInterfaceAndReleaseStream (*worker_acctmgr_stream,  
            IID_IAcctMgr, (void**) &local_acctmgr);
		worker_acctmgr_stream = NULL;
	}
	int function_pick;
	int atype_pick;
	int amount_pick;
	int bal;
	int acct_id;
	while(!shutdown_worker) {
		if (loop_rate) Sleep(loop_rate);
		function_pick = getrandom(1,6);
		atype_pick = getrandom(1, 2);
		acct_id = getrandom(1, 1000);
		amount_pick = getrandom(1, 1000);
		switch(function_pick) {
		case 1:
		case 2: 
		case 3: 
		case 4: 
			printf("Get account balance from Acct %08d\n", acct_id);
			hr = local_acctmgr->GetAcctBal(atype_pick, acct_id, &bal);
			if (FAILED(hr) && (hr != E_INVALIDARG)) {
				printf("GetAcctBal failure.");
				shutdown_worker = 1;
			}
			break;
		case 5:
			printf("Withdraw $%d from Acct %08d\n", amount_pick, acct_id);
			hr = local_acctmgr->Withdraw(atype_pick, acct_id, amount_pick, &bal);
			if (FAILED(hr) && (hr != E_INVALIDARG)) {
				printf("Withdraw failure.");
				shutdown_worker = 1;
			}
			break;
		case 6:
			printf("Deposit $%d to Acct %08d\n", amount_pick, acct_id);
			hr = local_acctmgr->Deposit(atype_pick, acct_id, amount_pick, &bal);
			if (FAILED(hr) && (hr != E_INVALIDARG)) {
				printf("Deposit failure.");
				shutdown_worker = 1;
			}
			break;
		}	
	}
	local_acctmgr->Release();
	ReleaseMutex(worker_mutex);
}


void message_pump() {
    MSG msg;
    while (GetMessage(&msg, 0, 0, 0))
        DispatchMessage(&msg);
}

int main(int argc, char* argv[])
{
	parse_arguments(argc, argv);
	setup();
	_beginthread(simulate_clients, 0, NULL);
	message_pump();
	return 0;
}
