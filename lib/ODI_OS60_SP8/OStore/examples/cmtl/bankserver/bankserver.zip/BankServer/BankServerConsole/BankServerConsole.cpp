

#include "stdafx.h"
#include <stdio.h>
#include "../BankServerInterfaces_i.c"
#include "../BankServer_i.c"
#include "../BankMsgLog/BankMsgLogInterfaces_i.c"
#include "../BankMsgLog/BankMsgLog_i.c"
 
#define BUF_SIZE 16384

IBankConsole *Bank_con = NULL;
IBankMsgLogger *Bank_logger = NULL;
IPipeByte *console_pipe = NULL;

IStream **Bank_con_stream = NULL;
IStream **Bank_logger_stream = NULL;
IStream **console_pipe_stream = NULL;

void shutdown() {
	printf("Requesting shutdown of BankServer...\n");
	CoInitializeEx(0, COINIT_APARTMENTTHREADED);
	IBankConsole *local_Bank_con = NULL;
	IBankMsgLogger *local_Bank_logger = NULL;
	IPipeByte *local_console_pipe = NULL;
	if (Bank_con_stream) {
		CoGetInterfaceAndReleaseStream (*Bank_con_stream,  
            IID_IBankConsole, (void**) &local_Bank_con);
		Bank_con_stream = NULL;
	}
	if (Bank_logger_stream) {
		CoGetInterfaceAndReleaseStream (*Bank_logger_stream,  
            IID_IBankMsgLogger, (void**) &local_Bank_logger);
		Bank_logger_stream = NULL;
	}
	if (console_pipe_stream) {
		CoGetInterfaceAndReleaseStream (*console_pipe_stream,  
            IID_IPipeByte, (void**) &local_console_pipe);
		console_pipe_stream = NULL;
	}
	if (local_Bank_con) local_Bank_con->stop();
	if (local_console_pipe) {
		local_console_pipe->Release();
		local_console_pipe = NULL;
	}
	if (local_Bank_logger) {
		local_Bank_logger->Release();
		local_Bank_logger = NULL;
	}
	if (local_Bank_con) {
		local_Bank_con->Release();
		local_Bank_con = NULL;
	}
}

BOOL WINAPI ctrl_handler_routine(DWORD dwCtrlType) {
	shutdown();
	return false;
}

int main(int argc, char* argv[])
{
	HRESULT hr;
	BOOL rval = SetConsoleCtrlHandler(ctrl_handler_routine, true);
	if (!rval) {
		printf("Error calling SetConsoleCtrlHandler.\n");
		shutdown();
	}
	printf("Requesting BankServer startup.\n");
	CoInitializeEx(0, COINIT_APARTMENTTHREADED);
	hr = CoCreateInstance(CLSID_BankMsgLogger, 0,
                  CLSCTX_INPROC_SERVER, 
                  IID_IBankMsgLogger, 
                  (void**)&Bank_logger);
	if (FAILED(hr)) {
		printf("CoCreateInstance of CLSID_BankMsgLogger failed.\n");
		printf("Check to see if the BankServer has been registered.\n");
		shutdown();
	}
    Bank_logger_stream = new IStream *;
	hr = CoMarshalInterThreadInterfaceInStream
    (IID_IBankMsgLogger, Bank_logger, Bank_logger_stream);
	hr = Bank_logger->setup(&console_pipe);
	if (FAILED(hr)) {
		printf("Failed to setup Bank_logger.\n");
		shutdown();
	}
    console_pipe_stream = new IStream *;
	hr = CoMarshalInterThreadInterfaceInStream
    (IID_IPipeByte, console_pipe, console_pipe_stream);
	hr = CoCreateInstance(CLSID_BankConsole, NULL, CLSCTX_LOCAL_SERVER, 
		                  IID_IBankConsole, (void **) &Bank_con);
	if (FAILED(hr)) {
		printf("CoCreateInstance of CLSID_BankConsole failed.\n");
		printf("Check to see if the BankServer has been registered.\n");
		shutdown();
	}
    Bank_con_stream = new IStream *;
	hr = CoMarshalInterThreadInterfaceInStream
    (IID_IBankConsole, Bank_con, Bank_con_stream);
	hr = Bank_con->start(console_pipe);
	if (FAILED(hr)) {
		printf("Error starting Bank Console.\n");
		shutdown();
	}

	Bank_con->Release();
	console_pipe->Release();
	Bank_logger->Release();
    MSG msg;
    while (GetMessage(&msg, 0, 0, 0))
        DispatchMessage(&msg);
	return 0;
}
