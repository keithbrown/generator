// BankMsgLogger.cpp : Implementation of CBankMsgLogger
#include "stdafx.h"
#include "BankMsgLog.h"
#include "BankMsgLogger.h"

/////////////////////////////////////////////////////////////////////////////
// CBankMsgLogger


STDMETHODIMP CBankMsgLogger::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IBankMsgLogger
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CBankMsgLogger::log()
{
	// TODO: Add your implementation code here

	return S_OK;
}

STDMETHODIMP CBankMsgLogger::setup(IPipeByte **ppOut)
{
	return this->QueryInterface(IID_IPipeByte, (void **)ppOut);
}


STDMETHODIMP CBankMsgLogger::Pull(BYTE* buf, ULONG cRequest, ULONG* pcReturned)
{		
	// not implemented.
	return E_NOTIMPL;
}

STDMETHODIMP CBankMsgLogger::Push(BYTE* buffer, ULONG cSent)
{
	buffer[cSent] = 0;
	printf("%s", (const char *)buffer);
	return S_OK;
}

