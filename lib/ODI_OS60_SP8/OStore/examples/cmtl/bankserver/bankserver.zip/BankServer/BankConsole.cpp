// BankConsole.cpp : Implementation of CBankConsole
#include "stdafx.h"
#include "BankServer.h"
#include "BankServerInterfaces.h"
#include "BankConsole.h"

/////////////////////////////////////////////////////////////////////////////
// CBankConsole

STDMETHODIMP CBankConsole::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IBankConsole
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CBankConsole::stop()
{
	allow_clients = false;  // signal clients to end.
	int i=0;
	while(clients_cnt) {  
		if (i++ == 6) break;  // we won't wait forever!
		Sleep(500);  // sleep for 100ms
	}
	if (bank_init) delete bank_init;
	bank_init = 0;
	return S_OK;
}

STDMETHODIMP CBankConsole::start(IPipeByte *pIn)
{
	HRESULT hr;
	char msg[] = "BankServer: starting\n";
	hr = pIn->Push((unsigned char *)msg, strlen(msg)+1);
	if (bank_init != NULL) return E_FAIL;
	bank_init = new bank_initialize(pIn);
	cpm = bank_init->get_cache_pool_manager();
	allow_clients = true;
	log_message("BankServer: ready\n");
	return S_OK;
}
