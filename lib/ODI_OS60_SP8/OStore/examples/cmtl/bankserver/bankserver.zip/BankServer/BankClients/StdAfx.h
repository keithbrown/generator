// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__B97E61EF_5886_4D5D_B1F8_2ACDA48DA7A7__INCLUDED_)
#define AFX_STDAFX_H__B97E61EF_5886_4D5D_B1F8_2ACDA48DA7A7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define _WIN32_DCOM

#define STRICT
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0400
#endif
#define _ATL_APARTMENT_THREADED

// TODO: reference additional headers your program requires here
#include "../BankServer.h"
#include "../BankServerInterfaces.h"
#include <atlbase.h>


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__B97E61EF_5886_4D5D_B1F8_2ACDA48DA7A7__INCLUDED_)
