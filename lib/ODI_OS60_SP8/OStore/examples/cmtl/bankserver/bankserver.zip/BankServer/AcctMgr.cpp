// AcctMgr.cpp : Implementation of CAcctMgr
#include "stdafx.h"
#include "BankServer.h"
#include "BankServerInterfaces.h"
#include "AcctMgr.h"
#include "BankUtils/BankUtils.h"

extern os_cache_pool_manager* cpm;

/////////////////////////////////////////////////////////////////////////////
// CAcctMgr


STDMETHODIMP CAcctMgr::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IAcctMgr
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}


os_basic_transaction_context *
CAcctMgr::get_update_context() {
	static os_basic_transaction_context *ctx = 
		os_basic_transaction_context::create();
	return ctx;
}

os_basic_transaction_context *
CAcctMgr::get_readonly_context() {
	static os_basic_transaction_context *ctx = 
		os_basic_transaction_context::create(os_transaction_context::read_only, 
			os_transaction_context::read_committed);
	return ctx;
}


CAccount* CAcctMgr::get_account(int acct_type, int id)
{
	os_set *accts = NULL;
	if (acct_type == 1) // checking accounts
		accts =	(os_set*)((cpm->get_root(LOGICAL_CHECKING_ROOT_NAME))->get_root_value());
	if (acct_type == 2) // savings accounts
		accts =	(os_set*)((cpm->get_root(LOGICAL_SAVINGS_ROOT_NAME))->get_root_value());

	// query for the account
	os_database *db = os_database::of(accts);

	CAccount *a=NULL;
	if (acct_type == 1) // checking accounts
		a = CAccount::query_checking_by_id(id, db, accts);
	if (acct_type == 2) // savings accounts
		a = CAccount::query_savings_by_id(id, db, accts);
	db->release_pointer();
	return a;
}


STDMETHODIMP CAcctMgr::Withdraw(int acct_type, int acct_id, int amount, int *bal)
{
	OS_ESTABLISH_FAULT_HANDLER {
		OS_ENTER_CMTL {
			int new_bal = 0;
			OS_BEGIN_VT (vt1, *get_update_context()) {
				CAccount* a = get_account(acct_type, acct_id);

				if (!a) // account id in database?
					/* err_bad_acct_id.signal("Account %s not found in database", id); */
					return E_INVALIDARG;
				else { // try a withdrawal
					new_bal = a->debit(amount);
				if (new_bal < 0) 
					/* err_insuff_bal.signal("$%d exceeds balance", amount); */
					return E_INVALIDARG;
				}
			} OS_END_VT (vt1)
			*bal = new_bal;
			InterlockedIncrement(&txn_cnt);
		} OS_LEAVE_CMTL;
	} OS_END_FAULT_HANDLER;
	return S_OK;
}

STDMETHODIMP CAcctMgr::GetAcctBal(int acct_type, int acct_id, int *bal)
{
	OS_ESTABLISH_FAULT_HANDLER {
		OS_ENTER_CMTL {
			OS_BEGIN_VT (vt2, *get_readonly_context()) {
				CAccount* a = get_account(acct_type, acct_id);

				if (!a) // account id in database?
					/* err_bad_acct_id.signal("Account %s not found in database", id); */
					return E_INVALIDARG;
				*bal = a->get_balance();
			} OS_END_VT (vt2)
			InterlockedIncrement(&txn_cnt);
		} OS_LEAVE_CMTL;
	} OS_END_FAULT_HANDLER;
	return S_OK;
}

STDMETHODIMP CAcctMgr::Deposit(int acct_type, int acct_id, int amount, int *bal)
{
	OS_ESTABLISH_FAULT_HANDLER {
		OS_ENTER_CMTL {
			OS_BEGIN_VT (vt3, *get_update_context()) {
				CAccount* a = get_account(acct_type, acct_id);

				if (!a) // account id in database?
					/* err_bad_acct_id.signal("Account %s not found in database", id); */
					return E_INVALIDARG;
				*bal = a->credit(amount);
			} OS_END_VT (vt3)
			InterlockedIncrement(&txn_cnt);
		} OS_LEAVE_CMTL;
	} OS_END_FAULT_HANDLER;
	return S_OK;
}
