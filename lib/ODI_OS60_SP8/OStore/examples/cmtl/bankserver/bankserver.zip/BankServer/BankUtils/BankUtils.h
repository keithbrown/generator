#ifdef BANKUTILS_EXPORTS
#define BANKUTILS_API __declspec(dllexport)
#else
#define BANKUTILS_API __declspec(dllimport)
#endif

#include "../BankMsgLog/BankMsgLogInterfaces.h"
#include "../BankMsgLog/BankMsgLog.h"
#include <ostore/cmtl.hh>
#include <ostore/coll.hh>

char *strndup(const char *other, size_t len);
void initialize_console_pipe(IPipeByte *client_console_pipe);
void release_console_pipe();
DWORD WINAPI bank_status_proc(LPVOID lpParameter);



// This is a singleton object which is created as soon as the server starts 
// and is deleted when the server shutsdown.  This object handles the 
// initalization of the server, CMTL, and databases.
class BANKUTILS_API bank_initialize  
{
private:
	os_cache_pool_manager *cpm;
	void configure_caches_and_start_cpm(ifstream &xml_config);
	HANDLE status_thread;
public:
	bank_initialize(IPipeByte *console_pipe);
	os_cache_pool_manager *get_cache_pool_manager() { return cpm; }
	virtual ~bank_initialize();
};

BANKUTILS_API extern long txn_cnt;
BANKUTILS_API void log_message(const char *msg);
BANKUTILS_API void log_message(BSTR msg);


