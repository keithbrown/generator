// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__C125C298_744F_4BB0_B75F_C333E7289878__INCLUDED_)
#define AFX_STDAFX_H__C125C298_744F_4BB0_B75F_C333E7289878__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define _WIN32_DCOM

#define STRICT
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x500
#endif
#define _ATL_APARTMENT_THREADED

// TODO: reference additional headers your program requires here
#include "../BankServer.h"
#include "../BankMsgLog/BankMsgLog.h"
#include <atlbase.h>

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__C125C298_744F_4BB0_B75F_C333E7289878__INCLUDED_)
