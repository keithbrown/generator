// BankUtils.cpp : Various utilities to help us do things.
//

#include "stdafx.h"


IGlobalInterfaceTable *g_pGIT = 0;

IPipeByte *console_pipe = NULL;
DWORD console_pipe_cookie = 0;
long exit_status_thread = 0;
long status_thread_exited = 0;
long txn_cnt = 0;


HRESULT init_GIT() {
   return CoCreateInstance(CLSID_StdGlobalInterfaceTable, 0,
            CLSCTX_INPROC_SERVER, 
            IID_IGlobalInterfaceTable, 
            (void**)&g_pGIT);
}


BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
			init_GIT();
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}



char *strndup(const char *other, size_t len) {
  if (!other) return NULL;
  char *new_str = new char[len+1];
  memcpy(new_str, other, len);
  new_str[len] = '\0';
  return new_str;
}

void initialize_console_pipe(IPipeByte *client_console_pipe) {
	
	// write marshaled object reference to global variable

   HRESULT hr = g_pGIT->RegisterInterfaceInGlobal(client_console_pipe, 
	   __uuidof(client_console_pipe), &console_pipe_cookie);
   if (SUCCEEDED(hr)) {
		client_console_pipe->AddRef();
		console_pipe = client_console_pipe;
   }
}

void release_console_pipe() {
	if (!console_pipe) return;
    g_pGIT->RevokeInterfaceFromGlobal(console_pipe_cookie);
	console_pipe->Release();
	console_pipe = NULL;
}




// configure and create the cache pool manager.
/* private */ void 
bank_initialize::configure_caches_and_start_cpm(ifstream &xml_config) {
  // configure cache pool manager
  os_cache_pool_manager_config* cpm_cfg =
    os_cache_pool_manager_config::create_from_xml(xml_config);
  // create cache pool manager with configuration information
  cpm = os_cache_pool_manager::create(*cpm_cfg);  
  delete cpm_cfg;
}



// Initialize everything
bank_initialize::bank_initialize(IPipeByte *console_pipe) : cpm(NULL)
{
	initialize_console_pipe(console_pipe);
	OS_ESTABLISH_FAULT_HANDLER {
		OS_ENTER_CMTL {
			char* bank_server_top = getenv("BankServerTop");
			if (!bank_server_top || (strlen(bank_server_top) < 1)) return;
			char config_info[256];
			sprintf(config_info, "%s\\account.xml", bank_server_top);
			ifstream xml_file(config_info, ios::nocreate);
			log_message("Configuring CMTL\n");
			configure_caches_and_start_cpm(xml_file);
			os_cache_pool_manager::get()->initialize_collections();
#if 0
			// initialize collections
			os_basic_transaction_context* ctx =
				os_basic_transaction_context::create();
			OS_BEGIN_VT (vt, *ctx) {
				os_collection::initialize();
			} OS_END_VT (vt);
			delete ctx;
#endif
		} OS_LEAVE_CMTL
	} OS_END_FAULT_HANDLER
   
	DWORD tid;
	status_thread = CreateThread(NULL, 0, bank_status_proc, 0, 0, &tid);
}

bank_initialize::~bank_initialize()
{
    log_message("BankServer is shutting down\n");
	exit_status_thread = 1;
	OS_ESTABLISH_FAULT_HANDLER {
		OS_ENTER_CMTL {
			cpm->shutdown();
			delete cpm;
		} OS_LEAVE_CMTL;
	} OS_END_FAULT_HANDLER;
	while(!status_thread_exited) Sleep(500);
	CloseHandle(status_thread);
	log_message("GoodBye\n");
	release_console_pipe();
}


void log_message(const char *msg) {
	if (!console_pipe) return;
	ULONG len = strlen(msg) +1;
    IPipeByte *local_console_pipe;
    HRESULT hr = g_pGIT->GetInterfaceFromGlobal(
		     console_pipe_cookie, __uuidof(local_console_pipe), 
			 (void**)&local_console_pipe);
    if (SUCCEEDED(hr)) {
		hr = local_console_pipe->Push((unsigned char *)msg, len);
    }
}


void log_message(BSTR msg) {
	USES_CONVERSION;
	log_message(OLE2CA(msg));
}


DWORD WINAPI bank_status_proc(LPVOID lpParameter) {
	long initial_cnt = txn_cnt;
	long final_cnt;
	long elapsed_cnt;
	long rate;
	char msg[40];
	while(!exit_status_thread) {
		Sleep(3000);
		final_cnt = txn_cnt;
		elapsed_cnt = final_cnt - initial_cnt;
		initial_cnt = final_cnt;
		rate = elapsed_cnt/3;
		sprintf(msg, "Txn rate: %d per second.\n", rate);
		log_message(msg);
	}
	status_thread_exited = 1;
	return 0;
}
