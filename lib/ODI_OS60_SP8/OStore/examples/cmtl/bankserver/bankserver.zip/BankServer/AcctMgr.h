// AcctMgr.h : Declaration of the CAcctMgr

#ifndef __ACCTMGR_H_
#define __ACCTMGR_H_

#include "resource.h"       // main symbols
#include "account/Account.h"

/////////////////////////////////////////////////////////////////////////////
// CAcctMgr
class ATL_NO_VTABLE CAcctMgr : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CAcctMgr, &CLSID_AcctMgr>,
	public ISupportErrorInfo,
	public IAcctMgr

{
private:
	CAccount* get_account(int acct_type, int id);
    os_basic_transaction_context *get_update_context(); 
    os_basic_transaction_context *get_readonly_context();

public:
	CAcctMgr()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_ACCTMGR)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CAcctMgr)
	COM_INTERFACE_ENTRY(IAcctMgr)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

public:

	// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);
	
	// IAcctMgr
	STDMETHOD(Deposit)(/*[in]*/ int acct_type, /*[in]*/ int acct_id, /*[in]*/ int amount, /*[out]*/ int *bal);
	STDMETHOD(GetAcctBal)(/*[in]*/ int acct_type, /*[in]*/ int acct_id, /*[out]*/ int *bal);
	STDMETHOD(Withdraw)(/*[in]*/ int acct_type, /*[in]*/ int acct_id, /*[in]*/ int amount, /*[out]*/ int *bal);
};

#endif //__ACCTMGR_H_
