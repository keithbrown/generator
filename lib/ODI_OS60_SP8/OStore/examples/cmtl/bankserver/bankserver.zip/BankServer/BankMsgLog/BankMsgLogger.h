// BankMsgLogger.h : Declaration of the CBankMsgLogger

#ifndef __BANKMSGLOGGER_H_
#define __BANKMSGLOGGER_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CBankMsgLogger
class ATL_NO_VTABLE CBankMsgLogger : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CBankMsgLogger, &CLSID_BankMsgLogger>,
	public ISupportErrorInfo,
	public IBankMsgLogger,
	public IPipeByte
{
public:
	CBankMsgLogger()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_BANKMSGLOGGER)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CBankMsgLogger)
	COM_INTERFACE_ENTRY(IBankMsgLogger)
	COM_INTERFACE_ENTRY(IPipeByte)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);


// IBankMsgLogger
public:
	STDMETHOD(setup)(/*[out]*/ IPipeByte **ppOut);
	STDMETHOD(log)();
	
//IPipeByte
    STDMETHOD(Pull)(BYTE* buf, ULONG cRequest, ULONG* pcReturned);
	STDMETHOD(Push)(BYTE* buffer, ULONG cSent);

};

#endif //__BANKMSGLOGGER_H_


