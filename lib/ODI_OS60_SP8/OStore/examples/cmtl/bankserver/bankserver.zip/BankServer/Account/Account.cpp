// Account.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "Account.h"
#define QS_SIZE 100

// logical names
ACCOUNT_API const char* LOGICAL_CHECKING_DB_NAME = "Checking Account Database";
ACCOUNT_API const char* LOGICAL_CHECKING_ROOT_NAME = "Checking Account Root";
ACCOUNT_API const char* LOGICAL_SAVINGS_DB_NAME = "Savings Account Database";
ACCOUNT_API const char* LOGICAL_SAVINGS_ROOT_NAME = "Savings Account Root";
ACCOUNT_API const char* CACHE_POOL_NAME = "Account Cache Pool";

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}



os_indexable_body(CAccount,account_id,int,os_index(CAccount,bpl)) 

// create an CAccount object
CAccount::CAccount(const char* n, int id, int b):
  name(dupl_string(n)), account_id(id), balance(b)
{
  /* empty */
}

// return a pointer to a new Account object
CAccount* CAccount::create(int id, const char* n, int b, os_database* db)
{
  // get a pointer to typespec for Account class
  os_typespec* ts = CAccount::get_os_typespec();
  // create an Account object
  return new(db, ts) CAccount(n, id, b);
}

// allocate storage to hold the string in s, copy s to the
// newly allocated storage, and return a pointer to the storage
char* CAccount::dupl_string(const char* s)
{
  if (!s) return NULL;
  int len = strlen(s)+1;
  char* p = new(os_cluster::with(this), os_typespec::get_char(),
		len) char [len];
  return strcpy(p, s);
}

// withdraw amount from account balance and return new balance; if
// balance is less than amount, do nothing and return negative value
int CAccount::debit(int amount)
{
  if ( (balance - amount) >= 0 )
    return balance -= amount;
  else
    return balance - amount;
}

// add amount to balance and return new balance
int CAccount::credit(int amount)
{
  return balance += amount;
}

CAccount* CAccount::query_checking_by_id(int id, os_database* db, os_set* coll)
{
	static const os_coll_query *checking_query = 
		&os_coll_query::create_pick("CAccount*",
			"account_id == (int)id_val",  db);
	os_bound_query bound_checking_query(*checking_query, 
		os_keyword_arg("id_val", id));
	return (CAccount*)coll->query_pick(bound_checking_query);
}

CAccount* CAccount::query_savings_by_id(int id, os_database* db, os_set* coll)
{
	static const os_coll_query *savings_query = 
		&os_coll_query::create_pick("CAccount*",
			"account_id == (int)id_val", db);
	os_bound_query bound_savings_query(*savings_query, 
		os_keyword_arg("id_val", id));
    return (CAccount*)coll->query_pick(bound_savings_query);
}




///////////////////////////////
// global functions

// overloading of << for displaying information about an account
ostream& operator<<(ostream& os, CAccount& a)
{
  cout << "Account id: " << a.get_account_id() << endl;
  cout << "Name: " << a.get_name() << endl;
  cout << "Balance: " << a.get_balance() <<  endl;
  return os;
}


